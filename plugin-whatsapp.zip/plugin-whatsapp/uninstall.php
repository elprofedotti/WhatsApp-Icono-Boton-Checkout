<?php
// Si uninstall no es llamado desde WordPress, salimos
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}

// Elimina las opciones guardadas en la base de datos
delete_option('whatsapp_plugin_options');
