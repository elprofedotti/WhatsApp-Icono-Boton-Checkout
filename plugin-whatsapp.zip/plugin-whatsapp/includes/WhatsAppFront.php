<?php
class WhatsAppFront {
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'add_whatsapp_button'));
		// Usa el filtro 'the_content' para agregar automáticamente el botón de WhatsApp a todas las páginas
		//add_filter('the_content', array($this, 'add_whatsapp_button'));
		if ($this->is_woocommerce_active()) {
            add_action('woocommerce_after_checkout_form', array($this, 'add_whatsapp_order_button'));
			add_action('wp_ajax_get_order_details', 'get_order_details');
			add_action('wp_ajax_nopriv_get_order_details', 'get_order_details');
			add_action('wp_ajax_update_order_status', 'update_order_status');
			add_action('wp_ajax_nopriv_update_order_status', 'update_order_status');
        }
		
	
    }
	function get_order_details() {
		// Comprueba si el usuario actual tiene un pedido pendiente
		$customer_orders = wc_get_orders(array(
			'customer' => get_current_user_id(),
			'status' => 'pending',
			'limit' => 1
		));

		if (count($customer_orders) > 0) {
			$order = $customer_orders[0];

			// Aquí debes obtener los detalles del pedido utilizando la API de WooCommerce
			$order_data = array(
				'id' => $order->get_id(),
				'items' => array(),
				'total' => $order->get_total()
			);

			foreach ($order->get_items() as $item_id => $item_data) {
				$product = $item_data->get_product();
				$order_data['items'][] = array(
					'product_name' => $product->get_name(),
					'quantity' => $item_data->get_quantity(),
					'price' => $product->get_price()
				);
			}

			// Devuelve los detalles del pedido como una respuesta JSON
			echo json_encode($order_data);
		} else {
			echo json_encode(array('error' => 'No pending orders found.'));
		}

		wp_die();
	}

	function update_order_status() {
		if (!isset($_POST['status']) || !isset($_POST['billing_data'])) {
			echo json_encode(array('success' => false, 'message' => 'No status or billing data provided.'));
			wp_die();
		}

		// Crea un nuevo pedido utilizando los datos proporcionados en el formulario de checkout
		$order = wc_create_order();

		// Asigna los datos de facturación al pedido
		$billing_data = $_POST['billing_data'];
		foreach ($billing_data as $key => $value) {
			$order->update_meta_data('_billing_' . $key, sanitize_text_field($value));
		}

		// Agrega los productos del carrito al pedido
		$cart = WC()->cart;
		foreach ($cart->get_cart() as $cart_item) {
			$order->add_product($cart_item['data'], $cart_item['quantity']);
		}

		// Establece el estado del pedido como 'en espera'
		$new_status = sanitize_text_field($_POST['status']);
		$order->update_status($new_status);

		// Guarda el pedido
		$order->save();

		// Vacía el carrito
		$cart->empty_cart();

		// Devuelve una respuesta JSON con el resultado de la operación
		echo json_encode(array('success' => true, 'message' => 'Order created and status updated.'));

		wp_die();
	}

	private function is_woocommerce_active() {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');

        return is_plugin_active('woocommerce/woocommerce.php');
    }
	
    public function enqueue_scripts() {
        wp_enqueue_style('whatsapp-plugin-css', plugins_url('../assets/css/style.css', __FILE__));
        wp_enqueue_script('whatsapp-plugin-js', plugins_url('../assets/js/script.js', __FILE__), array('jquery'), '1.0', true);
    }
	
	public function add_whatsapp_button($content) {
		$options = get_option('whatsapp_plugin_options');
		$telefono = $options['phone_number'];
		$retraso = $options['delay'];
		$posicion = $options['position'];
		$mensaje = $options['custom_message'];
		

		if ($telefono) {
        ?>
        <script type="text/javascript">
			var iconPosition = '<?php echo $posicion; ?>';
			var messagePosition = '<?php echo $posicion; ?>';
			
            function isMobileDevice() {
                return (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
            };

            function openWhatsApp() {
                if (isMobileDevice()) {
                    window.open('whatsapp://send?phone=<?php echo $telefono; ?>', '_blank');
                } else {
                    window.open('https://web.whatsapp.com/send?phone=<?php echo $telefono; ?>', '_blank');
                }
            }
			
			function getIconPositionStyle(posicion) {
                var positionStyle = {};

                switch (posicion) {
                    case 'left':
                        positionStyle.left = '20px';
                        break;
                    case 'center':
                        positionStyle.left = '50%';
                        positionStyle.transform = 'translateX(-50%)';
                        break;
                    case 'right':
                    default:
                        positionStyle.right = '20px';
                        break;
                }

                return positionStyle;
            }
			
			function getMessagePositionStyle(posicion) {
                var positionStyle = {};

                switch (posicion) {
                    case 'left':
                        positionStyle.left = '20px';
                        break;
                    case 'center':
                        positionStyle.left = '50%';
                        positionStyle.transform = 'translateX(-50%)';
                        break;
                    case 'right':
                    default:
                        positionStyle.right = '20px';
                        break;
                }

                return positionStyle;
            }
			
			/*actualizacion*/
			
			
			function openWhatsAppForm() {
				
				if (jQuery('#whatsapp-form-container').length > 0) {
                					
					return; // Si el formulario ya está en la página, no hacer nada
                }
				
				
                var formHTML = [
                    //'<div id="whatsapp-form-container" style="position: fixed; bottom: 70px; z-index: 1001; display: none;">',
					 '<div id="whatsapp-form-container" style="position: fixed; bottom: 70px; z-index: 1001; display: none; max-width: 300px; width: 100%;">',
                        '<form id="whatsapp-form" style="padding: 5px; background-color: #f1f1f1; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);">',
                            '<div style="margin-bottom: 10px; text-align: center;">',
                                //'<label for="whatsapp-form-name">Nombre:</label>',
                                '<input type="text" id="whatsapp-form-name" name="name" style="width: 90%; padding: 5px; margin-top: 5px;" placeholder="Nombre" required>',
                            '</div>',
                            '<div style="margin-bottom: 10px; text-align: center;">',
                                //'<label for="whatsapp-form-message">Mensaje:</label>',
                                '<textarea id="whatsapp-form-message" name="message" style="width: 90%; padding: 5px; margin-top: 5px; resize: none;" rows="4" placeholder="Mensaje" required></textarea>',
                            '</div>',
							'<div style="margin-bottom: 10px; text-align: center;">',
								'<button type="submit" style="background-color: #22c15e; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Enviar</button>',
								'<button type="button" id="close-form" style="background-color: #f1f1f1; color: #333; padding: 10px 20px; border: 1px solid #ccc; border-radius: 5px; cursor: pointer; margin-left: 10px;">Cerrar</button>',
							'</div>',
                        '</form>',
                    '</div>'
                ].join('');
				
				var formPositionStyle = getIconPositionStyle(iconPosition);
				var formTopPosition = parseInt(formPositionStyle.bottom) + 60; // Sumar 60 para ubicar el formulario encima del ícono


                var $formContainer = jQuery(formHTML);
                
				$formContainer.css({
					bottom: formTopPosition + 'px',
					left: formPositionStyle.left,
					right: formPositionStyle.right,
					transform: formPositionStyle.transform
				});
				
				jQuery('body').append($formContainer);
				
				//console.log('Form appended to body');

				
                $formContainer.slideDown();

                jQuery('#whatsapp-form').on('submit', function(e) {
                    e.preventDefault();

                    var name = jQuery('#whatsapp-form-name').val().trim();
                    var message = jQuery('#whatsapp-form-message').val().trim();
                    //var encodedMessage = encodeURIComponent(name + ': ' + message);
					
					var formattedMessage = "Mi nombre es " + name + ", " + message; // Agregar "Mi nombre es", el nombre, y un salto de línea (%0A)
					var encodedMessage = encodeURIComponent(formattedMessage);
					
                    if (isMobileDevice()) {
                        window.open('whatsapp://send?phone=<?php echo $telefono; ?>&text=' + encodedMessage, '_blank');
                    } else {
                        window.open('https://web.whatsapp.com/send?phone=<?php echo $telefono; ?>&text=' + encodedMessage, '_blank');
                    }

                    /*
					$formContainer.slideUp(function() {
                        $formContainer.remove();
                    });
					*/
                });
				
				//controlador de eventos click del boton Cerrar
				jQuery(document).on('click', '#whatsapp-form button[type="button"]', function() {
				  closeWhatsAppForm();
				});
            }
			
			
			function closeWhatsAppForm() {
			  //console.log('closeWhatsAppForm() called');
			  var $formContainer = jQuery('#whatsapp-form-container');
			  //console.log($formContainer);
			  $formContainer.slideUp(function() {
				//console.log('slide animation complete');
				$formContainer.remove();
			  });
			}
			
			
			/*--------------*/

            jQuery(document).ready(function($) {
				setTimeout(function() {
					var positionStyle = getIconPositionStyle('<?php echo $posicion; ?>');
					var messagePositionStyle = getMessagePositionStyle('<?php echo $posicion; ?>');
					
					


                    var whatsappIcon = jQuery('<a>', {
                        //onclick: 'openWhatsApp()',
						//onclick: 'openWhatsAppForm()', // Cambiar el onclick para abrir el formulario en lugar de WhatsApp directamente
						click: function() { openWhatsAppForm(this); }, // Cambiar el onclick para abrir el formulario en lugar de WhatsApp directamente
                        css: $.extend({
                            position: 'fixed',
                            bottom: '20px',
                            zIndex: '1000',
                            width: '50px',
                            height: '50px',
                            display: 'block',
                            cursor: 'pointer'
                        }, positionStyle),
                        html: '<img src="<?php echo plugins_url('../assets/whatsapp-icon.png', __FILE__); ?>" alt="WhatsApp" style="width: 100%; height: 100%;" />'
                    });

                    var whatsappMessage = $('<div>', {
                        css: $.extend({
                            position: 'fixed',
                            bottom: '80px',
                            zIndex: '1000',
                            backgroundColor: '#22c15e',
                            borderRadius: '25px',
                            padding: '10px 20px',
                            color: 'white',
                            fontWeight: 'bold',
                            display: '<?php echo $mensaje ? "block" : "none"; ?>'
                        }, messagePositionStyle),
                        text: '<?php echo $mensaje; ?>'
                    });
					
					$('body').append(whatsappIcon);
                    setTimeout(function() {
                        $('body').append(whatsappMessage);
                    }, 3000); // 3 segundos de retraso para mostrar el mensaje
					
					
					
				}, <?php echo $retraso; ?>);
            });
        </script>
        <?php
    
		}
	}

    
	
	public function add_whatsapp_order_button() {
		$options = get_option('whatsapp_plugin_options');
		if (isset($options['enable_checkout']) && $options['enable_checkout']) {
			?>
			<button type="button" id="finalizar_compra_whatsapp" class="button whatsapp-order-button">
				<?php _e('Finish Order via WhatsApp', 'whatsapp-plugin'); ?>
			</button>
			<script type="text/javascript">
				jQuery(document).ready(function ($) {
					$(".whatsapp-order-button").click(function () {
						// 1. Obtén los detalles del pedido utilizando la API de WooCommerce
						var data = {
							'action': 'get_order_details'
						};

						$.post(woocommerce_params.ajax_url, data, function (response) {
							var orderDetails = JSON.parse(response);

							// 2. Envía la información del pedido al número de WhatsApp configurado
							var phoneNumber = "<?php echo $options['phone_number']; ?>";
							var message = "Pedido: " + orderDetails;
							//var whatsappUrl = "https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + encodeURIComponent(message);
							var whatsappUrl = (isMobileDevice() ? "https://api.whatsapp.com" : "https://web.whatsapp.com") + "/send?phone=" + phoneNumber + "&text=" + encodeURIComponent(message);
							
							window.open(whatsappUrl, '_blank');

							// 3. Actualiza el estado del pedido a 'en espera'
							var data = {
								'action': 'update_order_status',
								'status': 'on-hold'
							};

							$.post(woocommerce_params.ajax_url, data, function (response) {
								if (response.success) {
									alert('El estado del pedido se ha actualizado a "en espera".');
								} else {
									alert('Hubo un problema al actualizar el estado del pedido.');
								}
							});
						});
					});
				});
			</script>
			<?php
		}
	}

}
