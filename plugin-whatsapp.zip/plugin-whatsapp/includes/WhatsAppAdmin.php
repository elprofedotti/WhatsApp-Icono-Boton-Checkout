<?php
class WhatsAppAdmin {
    public function __construct() {
        add_action('admin_menu', array($this, 'register_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings_page() {
        add_options_page(
            'WhatsApp Plugin', 
            'WhatsApp Plugin', 
            'manage_options', 
            'whatsapp_plugin_settings', 
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        register_setting('whatsapp_plugin_settings', 'whatsapp_plugin_options');
        add_settings_section('whatsapp_plugin_general', 'General Settings', null, 'whatsapp_plugin_settings');
        
        // Aquí se agregan los campos para los ajustes
        add_settings_field('phone_number', 'Celular', array($this, 'phone_number_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_general');
        
		add_settings_field('custom_message', 'Mensaje globo', array($this, 'custom_message_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_general');
		add_settings_field('delay', 'Retraso (segundos)', array($this, 'delay_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_general');
		add_settings_field('enable_checkout', 'Agregar botón en el checkout', array($this, 'enable_checkout_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_general');
		add_settings_field('position', 'Posición', array($this, 'position_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_general');
		
		// Agregamos una nueva sección y campo para la posición del icono
		//add_settings_section('whatsapp_plugin_display', 'Display Settings', null, 'whatsapp_plugin_settings');
		//add_settings_field('position', 'Posición', array($this, 'position_callback'), 'whatsapp_plugin_settings', 'whatsapp_plugin_display');
		
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Contactar por Whatsapp</h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('whatsapp_plugin_settings');
                do_settings_sections('whatsapp_plugin_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    // Funciones de callback para cada campo de ajuste
    public function phone_number_callback() {
        $options = get_option('whatsapp_plugin_options');
        echo '<input type="text" id="phone_number" name="whatsapp_plugin_options[phone_number]" value="' . esc_attr($options['phone_number']) . '">';
		
    }
    public function delay_callback() {
		$options = get_option('whatsapp_plugin_options');
		echo '<input type="number" min="0" step="1" id="delay" name="whatsapp_plugin_options[delay]" value="' . esc_attr($options['delay']) . '">';
		
	}
	
	public function custom_message_callback() {
        $options = get_option('whatsapp_plugin_options');
        echo '<input type="text" id="custom_message" name="whatsapp_plugin_options[custom_message]" value="' . esc_attr($options['custom_message']) . '">';
		
    }

	public function enable_checkout_callback() {
		$options = get_option('whatsapp_plugin_options');
		$checked = isset($options['enable_checkout']) ? 'checked' : '';
		echo '<input type="checkbox" id="enable_checkout" name="whatsapp_plugin_options[enable_checkout]" ' . $checked . '>';
		
	}
	public function position_callback() {
		$options = get_option('whatsapp_plugin_options');
		$position = isset($options['position']) ? $options['position'] : '';

		$html = '<select id="position" name="whatsapp_plugin_options[position]">';
		$html .= '<option value="left" ' . selected($position, 'left', false) . '>Izquierda</option>';
		$html .= '<option value="center" ' . selected($position, 'center', false) . '>Centro</option>';
		$html .= '<option value="right" ' . selected($position, 'right', false) . '>Derecha</option>';
		$html .= '</select>';

		echo $html;
	}
}
