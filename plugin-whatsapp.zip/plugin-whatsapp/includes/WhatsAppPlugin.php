<?php
class WhatsAppPlugin {
    public static function initialize() {
        $admin = new WhatsAppAdmin();
        $front = new WhatsAppFront();
    }
}