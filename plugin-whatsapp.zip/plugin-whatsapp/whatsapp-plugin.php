<?php
/**
 * Plugin Name: WhatsApp Contacto y Ckeckout
 * Description: Agrega el icono de Whatsapp en las paginas, y ademas si esta marcada la opcion, agrega un boton en la pagina de checkout para finalizar el pedido por whatsapp.
 * Version: 1.0
 * Author: @elprofedotti
 * License: GPL-2.0+
 * Text Domain: whatsapp-plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'includes/WhatsAppPlugin.php';
require_once plugin_dir_path(__FILE__) . 'includes/WhatsAppAdmin.php';
require_once plugin_dir_path(__FILE__) . 'includes/WhatsAppFront.php';

WhatsAppPlugin::initialize();